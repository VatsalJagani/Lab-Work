Indexes, views and triggers

