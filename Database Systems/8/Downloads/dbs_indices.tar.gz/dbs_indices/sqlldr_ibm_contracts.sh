sqlldr userid=jpandya skip=1 bad=bad_ibm_contracts.csv data=csv/datadump.csv control=ctl/datadump.ctl discard=discard_ibm_contracts.log
